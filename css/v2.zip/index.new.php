<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0"> -->
    <meta name="viewport" content="width=768">

    <title>JU$T 돈을 모으는 즐거운 방법!</title>
    <link rel="stylesheet" href="./js/flexslider/flexslider.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="./js/jquery.bxslider/jquery.bxslider.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="./css/new.css?v=2">
    <link rel="stylesheet" href="./css/new.section1.css?v=2">
    <link rel="stylesheet" href="./css/new.section2.css?v=2">
    <link rel="stylesheet" href="./css/new.section3.css?v=2">
    <link rel="stylesheet" href="./css/new.section4.css?v=2">
    <link rel="stylesheet" href="./css/new.section5.css?v=2">
    <link rel="stylesheet" href="./css/new.section6.css?v=2">
    <link rel="stylesheet" href="./css/new.section7.css?v=2">
    <link rel="stylesheet" href="./css/new.section8.css?v=2">
    <link rel="stylesheet" href="./css/new.section9.css?v=2">
</head>

<body>
    <!-- 최상단 -->
    <section id="SECTION01">
        <div class="container">
            <div class="text-box">
                <div class="title-text">
                    돈을 모으는<br/> <strong><span class="underline">즐거운<span></span></span> 방법</strong>
                </div>
                <div class="subtitle-text">목적 달성 중심 펀세이빙 저스트</div>
            </div>
        </div>
    </section>

    <!-- 저축이 즐거워집니다. -->
    <section id="SECTION02">
        <div class="container pos-rel">
        		<div class="group_02_txt1">지금, 저축이 지겹다고 느껴진다면?</div>
        		<div class="group_02_txt2">저축이 즐거워집니다.</div>

  		      <div class="space114"></div>
        		<ul class="group_02_in_box_wrap">
        			<li class="clearfix">
        				<div class="group_02_txt3">저축을 항상 실패한다면?</div>
        				<div class="group_02_img"><img src='/images.new/main_pc/g2_01.png'></div>
        				<div class="group_02_txt4">
        					돈이 아닌 <span class="underline">목적 중심 저축<span></span></span>으로<br>
        					<strong>성공적인 저축을 할 수 있습니다</strong>
        				</div>
        			</li>
        			<li class="clearfix">
        				<div class="group_02_txt3">저축에 흥미가 없다면?</div>
        				<div class="group_02_img"><img src='/images.new/main_pc/g2_02.png'></div>
        				<div class="group_02_txt4">
        					<span class="underline">6가지 저축 규칙<span></span></span>을 통해<br>
        					<strong>즐겁게 저축을 할 수 있습니다</strong>
        				</div>
        			</li>
        			<li class="clearfix">
        				<div class="group_02_txt3">저축하기가 어렵다면?</div>
        				<div class="group_02_img"><img src='/images.new/main_pc/g2_03.png'></div>
        				<div class="group_02_txt4">
        					<span class="underline">소액저축과 자동저축<span></span></span>을 통해<br>
        					<strong>편하고 쉽게 저축을 할 수 있습니다</strong>
        				</div>
        			</li>
        		</ul>
  		      <div class="space242"></div>
        </div>
    </section>

	<!-- 스탭1 슬라이더 -->
	<section id="SECTION03">
		<div class="group_03_slide">
			<div class="group_03_in_box_wrap">
				<div class="group_03_title_box">
					<div class="group_03_txt1"><strong>Step 01</strong>. 목표를 설정하세요</div>
					<div class="text_hiright_g3_bar1"></div>
				</div>
			</div>

		  <div class="slider">
			  <div class="bxslider">
  				<!-- 슬라이드 1 -->
  				<div class="group_03_in_box_wrap1">
  					<span class="group_03_in_box_wrap1_left">
  						<div class="group_03_txt2">목표와 자산을 한 곳에</div>
  						<div class="group_03_txt3">담을 수 있습니다.</div>
  						<div class="group_03_txt4">저축 습관을 통해 더 큰 목표를 이뤄보세요.</div>
  					</span>
  					<span class="group_03_in_box_wrap1_right">
  						<div class="group_03_img"><img src='/images.new/main_pc/g3_01.png'></div>
  					</span>
  				</div>
  				<!-- 슬라이드 2 -->
  				<div class="group_03_in_box_wrap1">
  				  <span class="group_03_in_box_wrap1_left">
  					<div class="group_03_txt3">아무런 신경을 쓰지 않아도</div>
  					<div class="group_03_txt2">일상에서 돈이 모입니다.</div>
  					<div class="group_03_txt4">저축 습관을 통해 더 큰 목표를 이뤄보세요.</div>
  				  </span>
  				  <span class="group_03_in_box_wrap1_right">
  					<div class="group_03_img"><img src='/images.new/main_pc/g3_02.png'></div>
  				  </span>
  				</div>
  				<!-- 슬라이드 3 -->
  				<div class="group_03_in_box_wrap1">
  				  <span class="group_03_in_box_wrap1_left">
    					<div class="group_03_txt3">간단한 통장 쪼개기로</div>
    					<div class="group_03_txt2">저축습관을 형성합니다.</div>
    					<div class="group_03_txt4">저축 습관을 통해 더 큰 목표를 이뤄보세요.</div>
  				  </span>
  				  <span class="group_03_in_box_wrap1_right">
  					  <div class="group_03_img"><img src='/images.new/main_pc/g3_03.png'></div>
  				  </span>
  				</div>
			  </div>
			</div>

		  </div>
		</div>
	</section>
	<!-- 스탭2 -->
	<section id="SECTION04">
		<br><br>
		<div class="container">
			<div class="group_04_in_box_wrap1">
				<div class="group_04_txt1"><strong>Step 02.</strong> 간편하게 사용하세요</div>
				<div class="text_hiright_g4_bar1"></div>
				<div class="group_04_txt2">자유로운 입출금과 적립내역으로</div>
				<div class="group_04_txt3">간편해서 쓰기 쉬운</div>
				<div class="group_04_txt4">데일리 저축</div>
			</div>
			<div  class="group_04_in_box_wrap2">
				<ul class="ul_tab">
					<li><a class="group_04_tab_txt1 on" data-for="#TAB1A" data-img="/images.new/main_pc/g4_01.png">입출금</a></li>
					<li><a class="group_04_tab_txt1" data-for="#TAB1B" data-img="/images.new/main_pc/g4_02.png">적립내역</a></li>
					<li><a class="group_04_tab_txt1" data-for="#TAB1C" data-img="/images.new/main_pc/g4_03.png">계좌개설</a></li>
				</ul>

				<div id="TAB1A" class="group_04_txt5 on">언제나 자유롭게 사용하는 입출금</div>
				<div id="TAB1B" class="group_04_txt5">어디서든 확인하는 목표별 적립내역</div>
				<div id="TAB1C" class="group_04_txt5">누구나 간단하게 만드는 계좌개설</div>
			</div>
			<div class="group_04_in_box_wrap3">
				<div class="group_04_img"><img id="TAB1_IMG" src="/images.new/main_pc/g4_01.png"></div>
			</div>
		</div>
	</section>
	<!-- 스탭3 -->
	<section id="SECTION05">
		<div class="container">
			<div class="group_05_in_box_wrap1">
				<div class="group_05_img"><img id="TAB2_IMG" src='/images.new/main_pc/g5_01.png'></div>
			</div>
			<div class="group_05_in_box_wrap2">
				<div class="group_05_txt1"><strong>Step 03.</strong> JUST를 즐겨보세요</div>
				<div class="text_hiright_g5_bar1"></div>
				<div class="group_05_txt2">6가지 규칙으로 즐기는</div>
				<div class="group_05_txt3">펀(Fun) 세이빙</div>
			</div>
			<div class="group_05_in_box_wrap3">
				<ul class="ul_tab2">
					<li class="group_05_tab_title on" data-for="#TAB2A" data-no="1">
						<div class="group_05_tab_img_box"><img src='/images.new/main_pc/g5_tab_01_over.png' data-src='/images.new/main_pc/g5_tab_01.png'></div>
						<div><span>슬금슬금</span> <span>규칙</span></div>
					</li>
					<li class="group_05_tab_title" data-for="#TAB2B" data-no="2">
						<div class="group_05_tab_img_box"><img src='/images.new/main_pc/g5_tab_02.png' data-src='/images.new/main_pc/g5_tab_02.png'></div>
						<div><span>반올림</span> <span>규칙</span></div>
					</li>
					<li class="group_05_tab_title" data-for="#TAB2C" data-no="3">
						<div class="group_05_tab_img_box"><img src='/images.new/main_pc/g5_tab_03.png' data-src='/images.new/main_pc/g5_tab_03.png'></div>
						<div><span>과소비</span> <span>규칙</span></div>
					</li>
					<li class="group_05_tab_title" data-for="#TAB2D" data-no="4">
						<div class="group_05_tab_img_box"><img src='/images.new/main_pc/g5_tab_04.png' data-src='/images.new/main_pc/g5_tab_04.png'></div>
						<div><span>예산절감</span> <span>규칙</span></div>
					</li>
					<li class="group_05_tab_title" data-for="#TAB2E" data-no="5">
						<div class="group_05_tab_img_box"><img src='/images.new/main_pc/g5_tab_05.png' data-src='/images.new/main_pc/g5_tab_05.png'></div>
						<div><span>52주</span> <span>규칙</span></div>
					</li>
					<li class="group_05_tab_title" data-for="#TAB2F" data-no="6">
						<div class="group_05_tab_img_box"><img src='/images.new/main_pc/g5_tab_06.png' data-src='/images.new/main_pc/g5_tab_06.png'></div>
						<div><span>월급날</span> <span> 규칙</span></div>
					</li>
				</ul>
				<div id="TAB2A" class="group_05_txt4 on">매일, 매주, 매달 일정한 금액을 저축합니다.</div>
				<div id="TAB2B" class="group_05_txt4"><span>결제금액을 1천원 단위로 반올림 한 후,</span> 잔돈을 만들어 저축합니다.</div>
				<div id="TAB2C" class="group_05_txt4">지정한 결제내역이 등장하면 저축합니다.</div>
				<div id="TAB2D" class="group_05_txt4"><span>일/주/월간 예산보다 지출을 절감했을 때,</span> 예산에서 남은 금액을 저축합니다.</div>
				<div id="TAB2E" class="group_05_txt4"><span>지정한 기간동안, 지정한 금액만큼을</span> 매주 증액하여 저축합니다.</div>
				<div id="TAB2F" class="group_05_txt4">월급의 일정비율을 저축합니다.</div>
			</div>
		</div>
	</section>
	<!-- JUST는 함께 성장하고 있습니다 -->
	<section id="SECTION06">
    <div class="container pos-rel">
  		<div class="group_06_in_box_wrap1">
  			<span>
  				<div class="group_06_txt1"><span>JUST는 함께</span> 성장하고 있습니다</div>
  				<div class="group_06_txt2"><span>JUST를 믿고 지지해주는 기업들과 함께</span> 정직하고, 착실하게 성장해 왔습니다. </div>
  				<div class="group_06_img1"><img src='/images.new/main_pc/g6.png' id="group_06_img"></div>
  				<div class="group_06_txt3">JUST를 알리고 있습니다.</div>
  				<div class="group_06_img2">
  					<ul>
  						<li><img src='/images.new/main_pc/g7_01.png'></li>
  						<li><img src='/images.new/main_pc/g7_02.png'></li>
  						<li><img src='/images.new/main_pc/g7_03.png'></li>
  					</ul>
  				</div>
  			</span>
  		</div>
    </div>
	</section>

	<!-- 슬라이더2 -->
	<section id="SECTION07">
    <div class="container pos-rel">
  		<div class="space141"></div>
  		<div class="group_07_slider only-desktop custom-navigation2">
  			<ul class="slides">
  				<li>
  					<img src='/images.new/main_pc/g8_01.png'>
  					<img src='/images.new/main_pc/g8_02.png'>
  					<img src='/images.new/main_pc/g8_03.png'>
  				</li>
  				<li>
  					<img src='/images.new/main_pc/g8_01.png'>
  					<img src='/images.new/main_pc/g8_02.png'>
  					<img src='/images.new/main_pc/g8_03.png'>
  				</li>
  			</ul>
  			<a href="#" class="flex-prev"><img src="/images.new/main_pc/btn_left.png"></a>
  			<a href="#" class="flex-next"><img src="/images.new/main_pc/btn_right.png"></a>
  		</div>
    </div>

		<div class="group_07_slider only-mobile custom-navigation-m">
			<ul class="slides">
				<li><img src='/images.new/main_pc/g8_01.png'></li>
				<li><img src='/images.new/main_pc/g8_02.png'></li>
				<li><img src='/images.new/main_pc/g8_03.png'></li>
			</ul>
			<a href="#" class="flex-prev"><img src="/images.new/main_mobile/btn_left.png"></a>
			<a href="#" class="flex-next"><img src="/images.new/main_mobile/btn_right.png"></a>

		</div>
	</section>

  <!-- 메일구독 -->
  <section id="SECTION08">
      <div class="title-text"><span>JUST는 언제나</span> 열려있습니다</div>
      <div class="subtitle-text"><span>자산관리의 시작 펀세이빙 ‘저스트’</span> 미리 사용해보고 혜택도 받아가자! </div>
      <div>
          <ul class="subscribe-form">
              <li class="email-input-li"><input type="text" name="email" id="email"></li>
              <li class="email-button-li"><img src="/images.new/main_pc/g9_btn.png" id="subscribe-button" onClick="subscribe();"></li>
          </ul>
      </div>
  </section>

  <!-- 앱다운로드 -->
  <section id="SECTION09">
      <div class="content-box">
          <div class="title-text">일상이 저축이 되는,<br/><strong>재밌고 간편한 공간</strong></div>
          <div class="store-link-box">
              <ul class="only-desktop">
                  <li><a href="#"><img src="/images.new/main_pc/btn_google.png"></a></li>
                  <li><a href="#"><img src="/images.new/main_pc/btn_apple.png"></a></li>
              </ul>
              <ul id="store-btn-ul" class="only-mobile2">
                  <li><a href="#"><img src="/images.new/main_mobile/btn_google.png"></a></li>
                  <li><a href="#"><img src="/images.new/main_mobile/btn_apple.png"></a></li>
              </ul>
          </div>
      </div>

      <!-- 푸터 -->
      <footer>
          <div class="footer-text">
              주식회사 부엔까미노<br>
              <div class="only-desktop">&nbsp;</div>
              주소, 서울시 마포구 마포대로 122 프론트원 12층<br>
              고객센터번호. 02-258-2588  카톡. @JUST<br>
              이메일. support@JUST.com<br><br>

              | <a href="#">서비스이용약관</a> | <a href="#">개인정보 처리방침</a> |
          </div>
      </footer>
  </section>

  <!-- 스크립트 -->
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.js"></script>
  <script type="text/javascript" src='./js/jquery-ui.min.js'></script>
  <script type="text/javascript" src="./js/flexslider/jquery.flexslider.js" defer></script>
  <script type="text/javascript" src="./js/jquery.bxslider/jquery.bxslider.js"></script>
  <script type="text/javascript" src="./js/new.ready.js?v=2"></script>
</body>
</html>
